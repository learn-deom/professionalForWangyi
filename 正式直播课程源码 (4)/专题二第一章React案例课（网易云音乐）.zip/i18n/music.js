export default {
	'cn':{
		'收藏频道':'收藏频道',
		'更多频道': '更多频道'
	},
	'eng':{
		'收藏频道':'collect channel',
		'更多频道': 'more channel'
	}
}
