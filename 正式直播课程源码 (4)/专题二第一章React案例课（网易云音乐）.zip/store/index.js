import user from './user'
import music from './music'

export default {
	user,
	music
}
