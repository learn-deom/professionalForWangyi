var b = require("./b.js");
exports.done = true;    //exports  {done:true}
console.log("a.js 执行完毕");    //a.js 执行完毕