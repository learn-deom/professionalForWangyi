var a = require("./a.js");
var b = require("./b.js");    //exports {done: false}  
console.log(a.done)    // exports {done: true}  
console.log(b.done)    //false