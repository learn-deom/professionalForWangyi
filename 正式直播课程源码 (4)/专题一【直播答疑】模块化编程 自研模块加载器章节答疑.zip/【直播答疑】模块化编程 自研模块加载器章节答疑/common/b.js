exports.done = false;     //exports {done: false}
var a = require("./a.js"); //{} 
console.log(a.done);      //undefined
console.log("b.js 执行完毕")   //b.js 执行完毕 