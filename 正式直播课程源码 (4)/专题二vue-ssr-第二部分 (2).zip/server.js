// 服务端入口

const express = require('express')
const app = express()
const path = require('path')
const App = require('./src/entry-server.js')
const vueServerRender = require('vue-server-renderer').createRenderer({
  template: require('fs').readFileSync(path.join(__dirname, './index.html'), 'utf-8')
})

app.get('*', async (request, response) => {

  const { url } = request
  const context = { url }
  const vm = await App(context)
  vueServerRender.renderToString(vm).then((html) => {
    response.end(html)
  }).catch(err => console.log(err))
})

app.listen(3001, () => {
  console.log('服务已开启')
})
