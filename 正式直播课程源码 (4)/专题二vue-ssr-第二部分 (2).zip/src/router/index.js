const VueRouter = require('vue-router')
const Vue = require('vue')

Vue.use(VueRouter)

module.exports = () => {
  return new VueRouter({
    mode: 'history',
    routes: [
      {
        path: '/',
        component: {
          template: '<h1>this is index page</h1>'
        },
        name: 'index'
      },
      {
        path: '/home',
        component: {
          template: '<h1>this is home page</h1>'
        },
        name: 'home'
      },
      {
        path: '/about',
        component: {
          template: '<h1>this is about page</h1>'
        },
        name: 'about'
      }
    ]
  })
}
