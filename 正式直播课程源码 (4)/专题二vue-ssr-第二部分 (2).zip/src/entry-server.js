// 前后端桥梁

const createApp = require('./app.js')

const getData = function () {
  return new Promise((reslove, reject) => {
    reslove('这是最新通知')
  })
}

module.exports = context => {
  return new Promise(async (resolve, reject) => {
    const { url } = context
    context.news = 'this is news'
    context.notice = await getData()
    const { app, router } = createApp(context)

    router.push(url)
    router.onReady(() => {
      const matchedComponents = router.getMatchedComponents()
      // 不反对大家用
      // if(matchedComponents.name == 'about') {
      //   getAboutData().then(reslove(App))
      // } else {
      //
      // }
      if (!matchedComponents.length) {
        return reject('view no found')
      }
      resolve(app)
    })
  })
}
