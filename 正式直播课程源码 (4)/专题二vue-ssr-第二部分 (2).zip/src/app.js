// 前端项目入口

const Vue = require('vue')
const createRouter = require('./router')
module.exports = context => {
  const router = createRouter()
  const app = new Vue({
    data: {
      news: context.news,
      notice: context.notice
    },
    router,
    template: `<div>
       <div>服务端渲染demo</div>
       <p>{{news}}</p>
        <p>{{notice}}</p>
    <ul>      <li>
          <router-link to="/">index</router-link>
      </li>
    
      <li>
          <router-link to="/home">home</router-link>
      </li>
     
      <li>
          <router-link to="/about">about</router-link>
      </li>
    </ul>
   <router-view></router-view>
</div>`
  })
  return { app, router }
}
