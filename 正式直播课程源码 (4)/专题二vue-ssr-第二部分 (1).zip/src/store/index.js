import Vue from 'vue'
import Vuex from 'vuex'
import {fetchBar} from './api/main.js'
import {fetchUserList} from './api/view1.js'
import {fetchFriendList} from './api/view2.js'
Vue.use(Vuex)



export default new Vuex.Store({
  state: {
    bar: 'tt',
    user: ['a'],
    friend: ['c']
  },

  mutations: {
    'SET_BAR' (state, data) {
      state.bar = data
    },
    'SET_USER' (state, data) {
      state.user = data
    },
    'SET_Friend' (state, data) {
      state.friend = data
    }

  },

  actions: {
    fetchBar ({commit}) {
      return fetchBar().then((data) => {
        commit('SET_BAR', data)
      }).catch((err) => {
        console.error(err)
      })
    },

    fetchUser({commit}) {
      return fetchUserList().then((data) => {
        commit('SET_USER', data)
      }).catch((err) => {
        console.error(err)
      })
    },

    fetchFriend({commit}) {
      return fetchFriendList().then((data) => {
        commit('SET_Friend', data)
      }).catch((err) => {
        console.error(err)
      })
    }
  }
})
