export const fetchFriendList = function(){
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      resolve(['小明','小红','小蓝']);
    }, 1000);
  });
}