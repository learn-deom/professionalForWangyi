export const fetchUserList = function(){
  return new Promise((resolve, reject) => {
    setTimeout(() => {

      resolve(['aa','bb','cc']);
    }, 1000);
  });
}