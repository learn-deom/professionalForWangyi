export const fetchBar = function() {
  return new Promise((resolve, reject) => {
    // file readt write
    // proxy
    // mysql read write
    setTimeout(() => {
      console.log(111111);
      resolve('bar 组件返回 ajax 数据');
    }, 1000);
  });
};

