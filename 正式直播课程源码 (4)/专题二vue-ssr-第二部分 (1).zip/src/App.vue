<template>
  <div class='main-content'>
    <h1>Vue.js SSR Template</h1>
    <router-view />
    <a class='fork-link' href='https://github.com/ccforward/vue-ssr/' title='Fork me on GitHub'>Fork me on GitHub</a>
  </div>
</template>
