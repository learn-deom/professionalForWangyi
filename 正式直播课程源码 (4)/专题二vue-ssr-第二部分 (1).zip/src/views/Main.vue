<template>
  <main>
    <img src="/public/logo.png">
    <h2 class="main-title" @click="getMain">This is Main View</h2>
    {{msg}}
    <a href="/" >Main</a>
    <a href="/view1">view1 </a>
    <a href="/view2">view2</a>
  </main>
</template>

<script>
  const fetchInitialData = ({ store }) => {
    return store.dispatch('fetchBar');
  };
  export default {
    mounted () {
      let store = this.$store;
      fetchInitialData({ store });
    },
    asyncData: fetchInitialData,

    methods: {
      meta () {
        return {
          title: 'Vue SSR Template',
          description: 'this is main description',
          keywords: 'view, main'
        }
      },
      getMain(){
        alert("hello main")
      }
    },
    computed: {
      msg() {

        return this.$store.state.bar;
      }
    }
  }
</script>