<template>
  <main>
    <img src="/public/logo.png">
    <h3 class="view1-title">This is View1</h3>
    <div>
      <span v-for="u in user">{{u}}</span>
    </div>

    <a href="/">Main</a>
    <a href="/view1">view1</a>
    <a href="/view2">view2</a>
  </main>
</template>
<script>

  const fetchInitialData = ({ store }) => {
    return store.dispatch('fetchUser');
  };
  export default {
    // 同构的考虑
    // 同构能力 服务端渲染报错-> 客服端渲染
    mounted () {
      let store = this.$store;
      fetchInitialData({ store });
    },
    created() {

    },

    asyncData: fetchInitialData,

    methods: {
      meta () {
        return {
          title: 'view1 title',
          description: 'this is view1 description',
          keywords: 'view, view1'
        }
      }
    },
    computed: {
      user() {
        return this.$store.state.user;
      }
    }
  }
</script>