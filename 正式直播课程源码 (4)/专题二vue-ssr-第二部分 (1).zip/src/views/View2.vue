<template>
  <main>
    <img src="/public/logo.png">
    <h3 class="view2-title">This is View2</h3>
    <a href="/">Main</a>
    <a href="/view1">view1</a>
    <a href="/view2">view2</a>

    <div>
      <span v-for="u in f">{{u}}</span>
    </div>
  </main>
</template>
<script>
  const fetchInitialData = ({ store }) => {
    return store.dispatch('fetchFriend');
  };
  export default {
    mounted () {
      let store = this.$store;
      fetchInitialData({ store });
    },

    asyncData: fetchInitialData,

    methods: {
      meta () {
        return {
          title: 'view2 title',
          h1: 'view2 - view2',
          description: 'this is view2 description',
          keywords: 'view, view2'
        }
      }
    },
    computed: {
      f() {
        return this.$store.state.friend;
      }
    }
  }
</script>