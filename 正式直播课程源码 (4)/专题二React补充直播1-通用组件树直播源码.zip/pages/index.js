
import react, { useState } from 'react'
import styles from './index.css'

function TreeItem ({ child,
  openKeys = [],
  onOpenKeysChange = () => {},
  onNodeClick = () => {},
  panelKey = '',
  onDelete,
  onCopy,
  setPanelKey
}) {
  let panel = <ul className={styles['tree__panel']}>
    <li className={styles['tree__panel__item']} onClick={e => {
      onDelete(panelKey)
    }}>删除</li>
    <li className={styles['tree__panel__item']} onClick={e => {
      onCopy(panelKey)
    }}>复制</li>
  </ul>
  return child.map(item => {
    if (item.children && item.children.length > 0) {
      return (
        <div className={styles['tree__item']} >
          <div
            className={styles['tree__item--title']}
            onClick={e => {
              let keys = [...openKeys]
              if (openKeys.includes(item.id)) {
                keys = keys.filter(k => k !== item.id)
              } else {
                keys.push(item.id)
              }
              onOpenKeysChange(keys)
            }}
          >

            <label>{item.title}</label>
            <div className={styles['tree__panelbox']}>
              <span>...</span>
              {panelKey === item.id && panel}
            </div>

          </div>
          {
            openKeys.includes(item.id) && <div className={styles['tree__item--list']}>
              <TreeItem
                child={item.children}
                setPanelKey={setPanelKey}
                panelKey={panelKey}
                openKeys={openKeys}
                onOpenKeysChange={onOpenKeysChange}
                onDelete={onDelete}
                onCopy={onCopy}
              />
            </div>
          }
        </div>
      )
    } else {
      return <div className={styles['tree__item--title']} onClick={e => onNodeClick(item.id, item)}>

        <label>{item.title}</label>

        <div className={styles['tree__panelbox']}>
          <span onClick={e => {
            setPanelKey(item.id)
          }}>...</span>
          {panelKey === item.id && panel}
        </div>
      </div>
    }
  })
}

function Tree ({ data, ...rest }) {
  let [panelKey, setPanelKey] = useState('')
  return (
    <div className={styles['tree']}>
      <TreeItem child={data} {...rest} panelKey={panelKey} setPanelKey={setPanelKey} />

    </div>
  )
}

const data = [
  {
    title: 'a',
    id: 'a',
    children: [
      {
        title: 'aa',
        id: 'aa'
      },
      {
        title: 'ab',
        id: 'ab'
      }
    ]
  },
  {
    title: 'b',
    id: 'b',
    children: [
      {
        title: 'ba',
        id: 'ba'
      },
      {
        title: 'bb',
        id: 'bb'
      }
    ]
  },
  {
    title: 'c',
    id: 'c',
    children: [
      {
        title: 'ca',
        id: 'ca'
      },
      {
        title: 'cb',
        id: 'cb'
      }
    ]
  }
]

export default function () {
  let [openKeys, setOpenKeys] = useState(['b', 'c'])
  return (
    <div className={styles.normal}>
      <Tree
        data={data}
        openKeys={openKeys}
        onOpenKeysChange={(keys) => {
          setOpenKeys(keys)
        }}
        onNodeClick={e => {

        }}
        onDelete={e => {

        }}
        onCopy={e => {

        }}
        render={(item) => {
          return (
            <div>{item.title}</div>
          )
        }}
      />
    </div>
  )
}
