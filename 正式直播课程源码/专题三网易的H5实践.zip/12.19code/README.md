# plainGame

#### 介绍

简易版飞机游戏

支持PC/手机，div+css + css3 +es6+实现


