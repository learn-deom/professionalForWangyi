(function(root, plug) {
	//校验微引擎
	var RULES = {
		"email": function() {
			//逻辑  value 字符串  1007486612@qq.com
			return /^\w+@\w+\.\w+$/.test(this.val());
		},
		"mobile": function() {
			return /^1\d{10}$/.test(this.val());
		},
		"private": function() {
			return /^\w{6,12}$/.test(this.val());
		}
	}

	$.fn[plug] = function(settings) {
		if (!this.is("form")) {
			return;
		}
		var __def__ = {
			initEvent: "input",
			sign: "dv",
			error: "* 输入不合法,请认真检查."
		}
		var ret = $.extend({}, __def__, settings);
		var keynote = this.find("input");
		var e;
		keynote.on(ret.initEvent, function() {
			var _this = $(this);
			_this.next("span").remove();
			$.each(RULES, function(key, func) {
				//data-dv-xxx
				var configName = _this.data(__def__.sign + "-" + key);
				if (configName) { //email
					var result = func.call(_this);
					if (!result) {
						//data-dv-xxx
						e = _this.data(__def__.sign + "-" + key + "-error") || __def__.error;
						_this.after("<span style='color:red; line-height:30px'>" + e + "</span>");
					}
				}
			});
		});
	}
	
	$.fn[plug]["expand"] = function(options){
		$.extend(RULES, options);
	}
})(this, "validate");


//以默认为优先 以用户配置为覆盖  extend
