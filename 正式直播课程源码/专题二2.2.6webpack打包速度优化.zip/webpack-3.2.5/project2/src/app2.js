 import jq from "jquery";
 import ma from "./modulea.js";

 
