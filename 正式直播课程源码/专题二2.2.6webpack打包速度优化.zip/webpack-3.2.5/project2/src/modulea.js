import m1 from "./mode1.js";
module.exports=function(){
	console.log("a");
	function a(){

	}
	function b(){
		
	}
}

export const a=function(){
	console.log('i am a');
}
export const b=function(){
	console.log('i am b');
}