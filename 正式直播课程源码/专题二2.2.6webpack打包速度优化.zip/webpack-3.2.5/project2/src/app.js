 import lod from "loadsh";
 //import './css/test1.css';
 import ma from "./modulea.js";
  import mb from "./moduleb.js";
 a(988989893232);
  
 /*require.ensure(["./moduleb"],function(){
    var ma=require('./modulea.js');
 })*/
 console.log(22);
 
 
