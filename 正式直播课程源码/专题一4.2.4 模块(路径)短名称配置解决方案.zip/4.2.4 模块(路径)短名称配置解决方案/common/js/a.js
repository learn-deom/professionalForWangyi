define(function( require, exports, module){
	var age = "40";
	exports.age = age;
});