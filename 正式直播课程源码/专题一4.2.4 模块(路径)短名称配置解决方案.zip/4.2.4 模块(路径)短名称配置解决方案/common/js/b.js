define(function( require, exports, module){
	 var a = require("a");
	 console.log(a);
	var sex = "男";
	exports.sex = sex;
});