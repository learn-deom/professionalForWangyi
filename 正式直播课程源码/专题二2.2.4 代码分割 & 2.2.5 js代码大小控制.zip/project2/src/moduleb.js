import m1 from "./mode1.js";
module.exports=function(){
	console.log("b")
}