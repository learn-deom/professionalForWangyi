// import ma from "./modulea.js";
 import mb from "./moduleb.js";
 import lod from "loadsh";
 import * from "./modulea.js"
 a();
 import("./modulea.js").then(function(res){
 
 });
 /*require.ensure(["./moduleb"],function(){
    var ma=require('./modulea.js');
 })*/
 console.log(22);
 
 
