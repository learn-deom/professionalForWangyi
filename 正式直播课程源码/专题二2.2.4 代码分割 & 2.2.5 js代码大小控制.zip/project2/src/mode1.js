module.exports={
	a:"this mode1"
}